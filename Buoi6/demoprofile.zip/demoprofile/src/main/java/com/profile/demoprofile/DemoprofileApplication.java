package com.profile.demoprofile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoprofileApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoprofileApplication.class, args);
	}

}
