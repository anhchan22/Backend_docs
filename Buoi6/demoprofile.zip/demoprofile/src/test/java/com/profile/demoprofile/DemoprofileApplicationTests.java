package com.profile.demoprofile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoprofileApplicationTests {

	@Test
	void contextLoads() {
	}

}
