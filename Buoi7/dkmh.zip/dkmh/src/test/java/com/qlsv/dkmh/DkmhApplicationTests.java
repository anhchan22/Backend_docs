package com.qlsv.dkmh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DkmhApplicationTests {

	@Test
	void contextLoads() {
	}

}
