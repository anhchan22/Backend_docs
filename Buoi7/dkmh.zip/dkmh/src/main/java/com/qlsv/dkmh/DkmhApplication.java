package com.qlsv.dkmh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DkmhApplication {

	public static void main(String[] args) {
		SpringApplication.run(DkmhApplication.class, args);
	}

}
